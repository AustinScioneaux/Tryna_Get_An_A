from keyboard import *


class Controls(object):
    def __init__(self, forward="up", backward="down", leftTurn="left", rightTurn="right", lf="w", rf="up", lb= "s", rb="down"): #lf, rf, lb, rb are for potentail single wheel control
        self.forward = forward
        self.backward = backward
        self.leftTurn = leftTurn
        self.rightTurn = rightTurn
        self.lf = lf
        self.rf = rf
        self.lb = lb
        self.rb = rb
    
    



